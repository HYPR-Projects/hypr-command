import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import crypto from 'crypto'
import { BigQuery } from '@google-cloud/bigquery'
import { google } from 'googleapis'
import nodemailer from 'nodemailer'

const app = express()
const PORT = process.env.PORT || 8080

app.use(cors({
  origin: [
    'https://hypr-command.netlify.app',
    process.env.FRONTEND_URL || 'http://localhost:5173',
    'http://localhost:5173',
    'http://localhost:4173',
  ]
}))
app.use(express.json())

// ══════════════════════════════════════════════════════════════════════════════
// BIGQUERY
// ══════════════════════════════════════════════════════════════════════════════
const bq = new BigQuery({
  projectId: process.env.GCP_PROJECT_ID,
  keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
})
const DATASET = process.env.BQ_DATASET || 'hypr_sales_center'

async function query(sql, params = []) {
  const [rows] = await bq.query({ query: sql, params, useLegacySql: false })
  return rows
}

// ══════════════════════════════════════════════════════════════════════════════
// GOOGLE SHEETS — Client lookup
// ══════════════════════════════════════════════════════════════════════════════
const SHEET_ID = process.env.CLIENTS_SHEET_ID || '1nd6UtJJ5fA81D9VZRiH2ZJGHYsiiv28LPzXhNRtd2aM'
let sheetsCache = { data: null, ts: 0 }
const CACHE_TTL = 60 * 1000 // 1 minute

async function getClientsFromSheet() {
  const now = Date.now()
  if (sheetsCache.data && (now - sheetsCache.ts) < CACHE_TTL) return sheetsCache.data

  const auth = new google.auth.GoogleAuth({
    scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
  })
  const sheets = google.sheets({ version: 'v4', auth })
  const res = await sheets.spreadsheets.values.get({ spreadsheetId: SHEET_ID, range: 'A:F' })
  const rows = res.data.values || []
  if (rows.length < 2) return []

  const data = rows.slice(1).map(row => ({
    agency: row[0] || '',
    client: row[1] || '',
    cp: row[2] || '',
    cpEmail: row[3] || '',
    cs: (row[4] && row[4] !== '#N/A' && row[4] !== 'Green Field') ? row[4] : null,
    csEmail: (row[5] && row[5] !== '#N/A') ? row[5] : null,
  })).filter(r => r.client)

  sheetsCache = { data, ts: now }
  return data
}

// ══════════════════════════════════════════════════════════════════════════════
// EMAIL — Nodemailer
// ══════════════════════════════════════════════════════════════════════════════
const mailer = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.EMAIL_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
})

const EMAIL_FROM = process.env.EMAIL_FROM || '"HYPR Command" <noreply@hypr.mobi>'
const FRONTEND_URL = process.env.FRONTEND_URL || 'https://hypr-command.netlify.app'

function fmtDate(d) {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('pt-BR')
}

function fmtCurrency(val) {
  if (!val && val !== 0) return '—'
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val)
}

function productTags(products) {
  return (products || []).map(p =>
    `<span style="display:inline-block;padding:2px 10px;background:rgba(51,151,185,0.12);color:#3397B9;border-radius:99px;font-size:12px;font-weight:600;margin-right:4px;">${p}</span>`
  ).join('')
}

function featureTags(features) {
  return (features || []).map(f =>
    `<span style="display:inline-block;padding:2px 10px;background:#EEF1F4;color:#4A6070;border-radius:99px;font-size:12px;margin-right:4px;">${f}</span>`
  ).join('')
}

// ── Email header/footer shared ──────────────────────────────────────────────
function emailHeader() {
  return `<div style="background:#1C262F;padding:28px 32px;">
    <div style="font-size:24px;font-weight:800;color:#fff;letter-spacing:-0.5px;font-family:'Helvetica Neue',Arial,sans-serif;">HYPR <span style="color:#3397B9;font-weight:400;font-size:14px;letter-spacing:0.08em;">Command</span></div>
  </div>`
}

function emailFooter() {
  return `<div style="padding:20px 32px;text-align:center;background:#F4F6F8;">
    <div style="color:#8DA0AE;font-size:11px;font-family:'Helvetica Neue',Arial,sans-serif;">HYPR Command — Notificação automática</div>
    <div style="color:#C4D0D8;font-size:10px;margin-top:4px;font-family:'Helvetica Neue',Arial,sans-serif;">Este e-mail foi enviado automaticamente. Não responda.</div>
  </div>`
}

function emailRow(label, value) {
  return `<tr>
    <td style="padding:10px 0;color:#8DA0AE;font-size:11px;text-transform:uppercase;letter-spacing:0.06em;width:140px;vertical-align:top;border-bottom:1px solid #EEF1F4;">${label}</td>
    <td style="padding:10px 0;color:#1C262F;font-size:13px;border-bottom:1px solid #EEF1F4;">${value}</td>
  </tr>`
}

function ctaButton(text, url, bg = '#3397B9') {
  return `<div style="text-align:center;margin-top:24px;">
    <a href="${url}" style="display:inline-block;background:${bg};color:#fff;padding:14px 32px;border-radius:10px;text-decoration:none;font-weight:700;font-size:14px;font-family:'Helvetica Neue',Arial,sans-serif;">${text}</a>
  </div>`
}

// ══════════════════════════════════════════════════════════════════════════════
// EMAIL TEMPLATES — Approved
// ══════════════════════════════════════════════════════════════════════════════

// ── Task Created → CP (Solicitante) ─────────────────────────────────────────
function emailTaskCreatedCP(t) {
  return `<div style="font-family:'Helvetica Neue',Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f6f8;">
    ${emailHeader()}
    <div style="background:#3397B9;padding:14px 32px;">
      <div style="color:#fff;font-size:13px;font-weight:600;letter-spacing:0.04em;">✅ SUA TASK FOI CRIADA COM SUCESSO</div>
    </div>
    <div style="padding:28px 32px;background:#fff;">
      <p style="color:#4A6070;font-size:14px;line-height:1.6;margin:0 0 20px;">
        Olá, <strong>${t.requestedBy}</strong>! Sua solicitação foi registrada e enviada para o CS responsável.
      </p>
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
        ${emailRow('Task', `<strong>#${t.id}</strong> — ${t.type}`)}
        ${emailRow('Cliente', `<strong>${t.client}</strong> ${t.agency ? `<span style="color:#8DA0AE;font-size:12px;">(${t.agency})</span>` : ''}`)}
        ${emailRow('CS Responsável', `<strong>${t.cs}</strong><br/><span style="color:#3397B9;font-size:12px;">${t.csEmail || '—'}</span>`)}
        ${emailRow('Produtos', productTags(t.products))}
        ${emailRow('Investimento', `<strong style="font-size:15px;">${fmtCurrency(t.budget)}</strong>`)}
        <tr>
          <td style="padding:10px 0;color:#8DA0AE;font-size:11px;text-transform:uppercase;letter-spacing:0.06em;width:140px;vertical-align:top;">Prazo</td>
          <td style="padding:10px 0;">
            <span style="display:inline-block;padding:4px 12px;background:rgba(239,68,68,0.1);color:#EF4444;border-radius:6px;font-weight:700;font-size:13px;">${fmtDate(t.deadline)}</span>
            <span style="color:#8DA0AE;font-size:12px;margin-left:6px;">(${t.sla || '—'})</span>
          </td>
        </tr>
      </table>
      <div style="background:#F4F6F8;border-radius:10px;padding:16px;border-left:3px solid #3397B9;margin-bottom:20px;">
        <div style="font-size:11px;color:#8DA0AE;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Briefing</div>
        <div style="color:#1C262F;font-size:13px;line-height:1.7;">${t.briefing}</div>
      </div>
      ${ctaButton('Ver Task no HYPR Command', FRONTEND_URL + '/#tasks')}
    </div>
    ${emailFooter()}
  </div>`
}

// ── Task Created → CS (Responsável) ─────────────────────────────────────────
function emailTaskCreatedCS(t) {
  return `<div style="font-family:'Helvetica Neue',Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f6f8;">
    ${emailHeader()}
    <div style="background:#EDD900;padding:14px 32px;">
      <div style="color:#1C262F;font-size:13px;font-weight:700;letter-spacing:0.04em;">📋 NOVA TASK RECEBIDA</div>
    </div>
    <div style="padding:28px 32px;background:#fff;">
      <p style="color:#4A6070;font-size:14px;line-height:1.6;margin:0 0 20px;">
        Olá, <strong>${t.cs}</strong>! Você recebeu uma nova solicitação de <strong>${t.requestedBy}</strong>.
      </p>
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
        ${emailRow('Task', `<strong>#${t.id}</strong> — ${t.type}`)}
        ${emailRow('Cliente', `<strong>${t.client}</strong> ${t.agency ? `<span style="color:#8DA0AE;font-size:12px;">(${t.agency})</span>` : ''}`)}
        ${emailRow('Solicitado por', `<strong>${t.requestedBy}</strong><br/><span style="color:#3397B9;font-size:12px;">${t.requesterEmail}</span>`)}
        ${emailRow('Produtos', productTags(t.products))}
        ${(t.features || []).length > 0 ? emailRow('Features', featureTags(t.features)) : ''}
        ${emailRow('Investimento', `<strong style="font-size:15px;">${fmtCurrency(t.budget)}</strong>`)}
        <tr>
          <td style="padding:10px 0;color:#8DA0AE;font-size:11px;text-transform:uppercase;letter-spacing:0.06em;width:140px;vertical-align:top;">Prazo</td>
          <td style="padding:10px 0;">
            <span style="display:inline-block;padding:6px 16px;background:#EF4444;color:#fff;border-radius:8px;font-weight:700;font-size:14px;">${fmtDate(t.deadline)}</span>
            <span style="color:#8DA0AE;font-size:12px;margin-left:6px;">(${t.sla || '—'})</span>
          </td>
        </tr>
      </table>
      <div style="background:#F4F6F8;border-radius:10px;padding:16px;border-left:3px solid #EDD900;margin-bottom:20px;">
        <div style="font-size:11px;color:#8DA0AE;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Briefing</div>
        <div style="color:#1C262F;font-size:13px;line-height:1.7;">${t.briefing}</div>
      </div>
      ${ctaButton('Ver Task no HYPR Command', FRONTEND_URL + '/#tasks', '#1C262F')}
    </div>
    ${emailFooter()}
  </div>`
}

// ── Task Completed → Requester ──────────────────────────────────────────────
function emailTaskCompleted(t) {
  return `<div style="font-family:'Helvetica Neue',Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f6f8;">
    ${emailHeader()}
    <div style="background:#22C55E;padding:14px 32px;">
      <div style="color:#fff;font-size:13px;font-weight:600;letter-spacing:0.04em;">✅ TASK CONCLUÍDA</div>
    </div>
    <div style="padding:28px 32px;background:#fff;">
      <p style="color:#4A6070;font-size:14px;line-height:1.6;margin:0 0 20px;">
        Sua task <strong>#${t.id} — ${t.type}</strong> para <strong>${t.client}</strong> foi concluída pelo CS <strong>${t.cs}</strong>.
      </p>
      ${t.docLink ? `<div style="text-align:center;margin:20px 0;">
        <a href="${t.docLink}" style="display:inline-block;background:#22C55E;color:#fff;padding:14px 32px;border-radius:10px;text-decoration:none;font-weight:700;font-size:14px;">📄 Acessar Documento</a>
      </div>` : ''}
      ${ctaButton('Ver no HYPR Command', FRONTEND_URL + '/#tasks')}
    </div>
    ${emailFooter()}
  </div>`
}

// ── Task → Iniciada (notifica o CP que abriu) ───────────────────────────────
function emailTaskStarted(t) {
  const safeMsg = (t.message || '').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br/>')
  return `<div style="font-family:'Helvetica Neue',Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f6f8;">
    ${emailHeader()}
    <div style="background:#3397B9;padding:14px 32px;">
      <div style="color:#fff;font-size:13px;font-weight:600;letter-spacing:0.04em;">▶ TASK INICIADA</div>
    </div>
    <div style="padding:28px 32px;background:#fff;">
      <p style="color:#4A6070;font-size:14px;line-height:1.6;margin:0 0 20px;">
        Sua task <strong>#${t.id} — ${t.type}</strong> para <strong>${t.client}</strong> foi iniciada pelo CS <strong>${t.cs}</strong>.
      </p>
      ${safeMsg ? `<div style="background:#EEF1F4;border-left:3px solid #3397B9;border-radius:6px;padding:14px 18px;margin:0 0 20px;">
        <div style="font-size:11px;color:#8DA0AE;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Comentário do CS</div>
        <div style="color:#1C262F;font-size:14px;line-height:1.55;">${safeMsg}</div>
      </div>` : ''}
      ${ctaButton('Ver no HYPR Command', FRONTEND_URL + '/#tasks')}
    </div>
    ${emailFooter()}
  </div>`
}

// ── Task → Editada (notifica CS responsável e CP solicitante) ────────────────
function emailTaskEdited(t) {
  const editedBy = t.editedBy || 'um usuário'
  const editedByEmail = t.editedByEmail || ''
  return `<div style="font-family:'Helvetica Neue',Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f6f8;">
    ${emailHeader()}
    <div style="background:#F59E0B;padding:14px 32px;">
      <div style="color:#fff;font-size:13px;font-weight:600;letter-spacing:0.04em;">✏️ TASK EDITADA</div>
    </div>
    <div style="padding:28px 32px;background:#fff;">
      <p style="color:#4A6070;font-size:14px;line-height:1.6;margin:0 0 20px;">
        A task <strong>#${t.id} — ${t.type}</strong> para <strong>${t.client}</strong> foi editada por <strong>${editedBy}</strong>${editedByEmail ? ` <span style="color:#3397B9;font-size:12px;">(${editedByEmail})</span>` : ''}. Confira as informações atualizadas:
      </p>
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
        ${emailRow('Tipo', t.type)}
        ${emailRow('Cliente', `<strong>${t.client}</strong> ${t.agency ? `<span style="color:#8DA0AE;font-size:12px;">(${t.agency})</span>` : ''}`)}
        ${emailRow('CS Responsável', `<strong>${t.cs}</strong>${t.csEmail ? `<br/><span style="color:#3397B9;font-size:12px;">${t.csEmail}</span>` : ''}`)}
        ${(t.products || []).length > 0 ? emailRow('Produtos', productTags(t.products)) : ''}
        ${(t.features || []).length > 0 ? emailRow('Features', featureTags(t.features)) : ''}
        ${t.budget ? emailRow('Investimento', `<strong>${fmtCurrency(t.budget)}</strong>`) : ''}
        ${emailRow('Prazo', `<strong>${fmtDate(t.deadline)}</strong>`)}
      </table>
      <div style="background:#F4F6F8;border-radius:10px;padding:16px;border-left:3px solid #F59E0B;margin-bottom:20px;">
        <div style="font-size:11px;color:#8DA0AE;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Briefing</div>
        <div style="color:#1C262F;font-size:13px;line-height:1.7;">${t.briefing}</div>
      </div>
      ${ctaButton('Ver no HYPR Command', FRONTEND_URL + '/#tasks')}
    </div>
    ${emailFooter()}
  </div>`
}

// ── Checklist → CP (Solicitante) ────────────────────────────────────────────
function emailChecklistCP(c) {
  return `<div style="font-family:'Helvetica Neue',Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f6f8;">
    ${emailHeader()}
    <div style="background:#22C55E;padding:14px 32px;">
      <div style="color:#fff;font-size:13px;font-weight:600;letter-spacing:0.04em;">✅ CHECKLIST ENVIADO COM SUCESSO</div>
    </div>
    <div style="padding:28px 32px;background:#fff;">
      <p style="color:#4A6070;font-size:14px;line-height:1.6;margin:0 0 20px;">
        Olá, <strong>${c.submittedBy}</strong>! O checklist da campanha foi registrado. Confira o resumo:
      </p>
      <div style="background:#F4F6F8;border-radius:12px;padding:20px;margin-bottom:20px;">
        <div style="font-size:18px;font-weight:800;color:#1C262F;margin-bottom:4px;">${c.campaignName}</div>
        <div style="font-size:13px;color:#8DA0AE;">${c.client} — ${c.agency || '—'}</div>
      </div>
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
        ${emailRow('Tipo', c.campaignType)}
        ${emailRow('Indústria', c.industry)}
        ${emailRow('Período', `<strong>${fmtDate(c.startDate)} → ${fmtDate(c.endDate)}</strong>`)}
        ${emailRow('Investimento', `<strong style="font-size:15px;">${fmtCurrency(c.investment)}</strong>`)}
        ${emailRow('Deal DV360', c.dealDv360 ? 'Sim' : 'Não')}
        ${emailRow('Formatos', `${(c.formats || []).join(', ')}${c.cpm ? ` | CPM: ${fmtCurrency(c.cpm)}` : ''}${c.cpcv ? ` | CPCV: ${fmtCurrency(c.cpcv)}` : ''}`)}
        ${emailRow('Produtos', productTags(c.products))}
        ${(c.features || []).length > 0 ? emailRow('Features', featureTags(c.features)) : ''}
        ${c.audiences ? emailRow('Audiências', c.audiences) : ''}
        ${c.pracasDetail ? emailRow('Praças', c.pracasDetail) : ''}
      </table>
      ${c.csName ? `<div style="background:rgba(51,151,185,0.08);border-radius:10px;padding:14px 16px;margin-bottom:20px;">
        <div style="font-size:13px;color:#3397B9;font-weight:600;">CS Responsável: ${c.csName} (${c.csEmail || '—'})</div>
      </div>` : ''}
      ${ctaButton('Ver Checklist no HYPR Command', FRONTEND_URL + '/#checklist-center')}
    </div>
    ${emailFooter()}
  </div>`
}

// ── Checklist → CS (Responsável) ────────────────────────────────────────────
function emailChecklistCS(c) {
  return `<div style="font-family:'Helvetica Neue',Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f6f8;">
    ${emailHeader()}
    <div style="background:#EDD900;padding:14px 32px;">
      <div style="color:#1C262F;font-size:13px;font-weight:700;letter-spacing:0.04em;">📋 NOVO CHECKLIST RECEBIDO</div>
    </div>
    <div style="padding:28px 32px;background:#fff;">
      <p style="color:#4A6070;font-size:14px;line-height:1.6;margin:0 0 20px;">
        Um novo checklist foi enviado por <strong>${c.submittedBy}</strong> para a campanha abaixo. Revise as informações:
      </p>
      <div style="background:#F4F6F8;border-radius:12px;padding:20px;margin-bottom:20px;">
        <div style="font-size:18px;font-weight:800;color:#1C262F;margin-bottom:4px;">${c.campaignName}</div>
        <div style="font-size:13px;color:#8DA0AE;">${c.client} — ${c.agency || '—'}</div>
        <div style="font-size:12px;color:#3397B9;margin-top:4px;">Enviado por: ${c.submittedBy} (${c.submittedByEmail})</div>
      </div>
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
        ${emailRow('Tipo', c.campaignType)}
        ${emailRow('Período', `<strong>${fmtDate(c.startDate)} → ${fmtDate(c.endDate)}</strong>`)}
        ${emailRow('Investimento', `<strong style="font-size:15px;">${fmtCurrency(c.investment)}</strong>`)}
        ${emailRow('Formatos', `${(c.formats || []).join(', ')}${c.cpm ? ` | CPM: ${fmtCurrency(c.cpm)}` : ''}${c.cpcv ? ` | CPCV: ${fmtCurrency(c.cpcv)}` : ''}`)}
        ${emailRow('Produtos', productTags(c.products))}
        ${(c.features || []).length > 0 ? emailRow('Features', featureTags(c.features)) : ''}
        ${c.audiences ? emailRow('Audiências', c.audiences) : ''}
      </table>
      ${c.observations ? `<div style="background:#FEFCE8;border-left:4px solid #EDD900;border-radius:8px;padding:16px 18px;margin:0 0 20px;">
        <div style="font-size:11px;color:#a07a00;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px;">⚠ Observações do CP</div>
        <div style="color:#1C262F;font-size:14px;line-height:1.55;white-space:pre-wrap;">${(c.observations || '').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br/>')}</div>
      </div>` : ''}
      ${ctaButton('Ver Checklist no HYPR Command', FRONTEND_URL + '/#checklist-center', '#1C262F')}
    </div>
    ${emailFooter()}
  </div>`
}

// ── Send email helper ───────────────────────────────────────────────────────
async function sendEmail(to, subject, html, cc) {
  if (!to) { console.warn('No recipient email, skipping'); return }
  try {
    const opts = { from: EMAIL_FROM, to, subject, html }
    if (cc) opts.cc = cc
    await mailer.sendMail(opts)
    console.log(`📧 Email sent to ${to}${cc ? ` (cc: ${cc})` : ''}: ${subject}`)
  } catch (err) {
    console.error(`❌ Failed to send email to ${to}:`, err.message)
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// REPORT HUB SYNC — write to prod_assets.checklist_info
// ══════════════════════════════════════════════════════════════════════════════
// The Report Hub reads from prod_assets.checklist_info (legacy table fed by a
// Sheets pipeline). Each checklist created/edited in HYPR Command is mirrored
// there so the Report Hub keeps working without any change to its codebase.
//
// On edits we DELETE-then-INSERT by short_token, so we never accumulate stale
// rows from the same Command-originated record. The legacy rows from the Sheets
// pipeline are preserved (they have their own short_tokens, no collision).
const REPORT_HUB_TABLE = 'site-hypr.prod_assets.checklist_info'

async function syncToReportHub(f, isEdit = false) {
  if (!f.short_token) {
    console.warn('Skipping Report Hub sync: missing short_token')
    return
  }

  // Pull dynamic per-product volumetries (sent by the new frontend) with
  // graceful fallback to the legacy fixed columns (older payloads).
  const num = v => {
    if (v === null || v === undefined || v === '') return 0
    const n = Number(v)
    return isNaN(n) ? 0 : n
  }
  const o2oImp        = num(f.O2O_imp        ?? f.o2o_impressoes)
  const o2oViews      = num(f.O2O_views      ?? f.o2o_views)
  const oohImp        = num(f.OOH_imp)
  const oohViews      = num(f.OOH_views)
  const o2oBonusImp   = num(f.O2O_bonus_imp   ?? f.bonus_o2o_impressoes)
  const o2oBonusViews = num(f.O2O_bonus_views ?? f.bonus_o2o_views)
  const oohBonusImp   = num(f.OOH_bonus_imp)
  const oohBonusViews = num(f.OOH_bonus_views)

  const formatsStr = Array.isArray(f.formats) ? f.formats.join(', ') : (f.formats || '')

  const row = {
    salesman: f.cp_name || f.submittedBy || null,
    agency: f.agency || null,
    industry: f.industry || null,
    start_date: f.start_date || null,
    end_date: f.end_date || null,
    client_name: f.client || null,
    campaign_type: f.campaign_type || null,
    campaign_name: f.campaign_name || null,
    sold_audiences: f.audiences || null,
    total_value: f.investment ? parseFloat(f.investment) : null,
    formats: formatsStr,
    contracted_o2o_display_impressions: o2oImp,
    contracted_o2o_video_completions:   o2oViews,
    contracted_ooh_display_impressions: oohImp,
    contracted_ooh_video_completions:   oohViews,
    bonus_o2o_display_impressions: o2oBonusImp,
    bonus_o2o_video_completions:   o2oBonusViews,
    bonus_ooh_display_impressions: oohBonusImp,
    bonus_ooh_video_completions:   oohBonusViews,
    cpm_amount:  f.cpm  ? parseFloat(f.cpm)  : null,
    cpcv_amount: f.cpcv ? parseFloat(f.cpcv) : null,
    short_token: f.short_token,
  }

  try {
    if (isEdit) {
      // Remove any prior Command-originated row for this short_token before re-inserting.
      // Note: this also removes legacy rows if a token happens to collide, but legacy
      // tokens don't follow the Command's generation pattern so collisions are unlikely.
      await bq.query({
        query: `DELETE FROM \`${REPORT_HUB_TABLE}\` WHERE short_token = '${f.short_token.replace(/'/g, "''")}'`,
        useLegacySql: false,
      })
    }
    // Insert via SQL (NOT streaming insert) — keeps the row immediately available
    // for DELETE/UPDATE without going through BigQuery's streaming buffer (which
    // Use raw triple-quoted strings (r"""...""") so any user content — backslashes,
    // newlines, single & double quotes — passes literally without escape processing.
    // The ONLY thing we need to handle is the closing delimiter """ appearing inside
    // the value (extremely unlikely from form input).
    const esc = v => {
      if (v === null || v === undefined) return 'NULL'
      if (typeof v === 'number') return String(v)
      const s = String(v).replace(/"""/g, '""\\"')
      return `r"""${s}"""`
    }
    const dateExpr = v => v ? `DATE '${String(v).replace(/'/g, "''")}'` : 'NULL'
    const cols = [
      'salesman','agency','industry','start_date','end_date','client_name','campaign_type',
      'campaign_name','sold_audiences','total_value','formats',
      'contracted_o2o_display_impressions','contracted_o2o_video_completions',
      'contracted_ooh_display_impressions','contracted_ooh_video_completions',
      'bonus_o2o_display_impressions','bonus_o2o_video_completions',
      'bonus_ooh_display_impressions','bonus_ooh_video_completions',
      'cpm_amount','cpcv_amount','short_token',
    ]
    const vals = [
      esc(row.salesman), esc(row.agency), esc(row.industry),
      dateExpr(row.start_date), dateExpr(row.end_date),
      esc(row.client_name), esc(row.campaign_type), esc(row.campaign_name),
      esc(row.sold_audiences), esc(row.total_value), esc(row.formats),
      esc(row.contracted_o2o_display_impressions), esc(row.contracted_o2o_video_completions),
      esc(row.contracted_ooh_display_impressions), esc(row.contracted_ooh_video_completions),
      esc(row.bonus_o2o_display_impressions),     esc(row.bonus_o2o_video_completions),
      esc(row.bonus_ooh_display_impressions),     esc(row.bonus_ooh_video_completions),
      esc(row.cpm_amount), esc(row.cpcv_amount), esc(row.short_token),
    ]
    const sql = `INSERT INTO \`${REPORT_HUB_TABLE}\` (${cols.join(', ')}) VALUES (${vals.join(', ')})`
    await bq.query({ query: sql, useLegacySql: false })
    console.log(`✅ Report Hub synced: ${f.short_token} (${f.client} — ${f.campaign_name})`)
  } catch (err) {
    // Don't fail the whole request if the Report Hub sync fails — log and continue.
    // The Command write to hypr_sales_center.checklists already succeeded.
    console.error(`⚠ Report Hub sync failed for ${f.short_token}:`, err.message)
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// BIGQUERY — Table DDL
// ══════════════════════════════════════════════════════════════════════════════
const PROJECT = process.env.GCP_PROJECT_ID
const SETUP_SQL = {
  campaigns: `
    CREATE TABLE IF NOT EXISTS \`${PROJECT}.${DATASET}.campaigns\` (
      id STRING, client STRING, campaign STRING, start_date DATE, end_date DATE,
      pacing_display FLOAT64, pacing_video FLOAT64, ctr FLOAT64, vtr FLOAT64,
      features ARRAY<STRING>, investment FLOAT64, created_at TIMESTAMP
    )`,
  tasks: `
    CREATE TABLE IF NOT EXISTS \`${PROJECT}.${DATASET}.tasks\` (
      id STRING, type STRING, client STRING, agency STRING,
      products ARRAY<STRING>, features ARRAY<STRING>,
      budget FLOAT64, briefing STRING, cs STRING, cs_email STRING,
      status STRING, deadline DATE, doc_link STRING,
      requested_by STRING, requester_email STRING,
      sla STRING, created_at TIMESTAMP, updated_at TIMESTAMP
    )`,
  checklists: `
    CREATE TABLE IF NOT EXISTS \`${PROJECT}.${DATASET}.checklists\` (
      id STRING, cp_name STRING, cp_email STRING, agency STRING,
      industry STRING, campaign_type STRING, client STRING, campaign_name STRING,
      start_date DATE, end_date DATE, investment FLOAT64,
      deal_dv360 BOOL, formats ARRAY<STRING>, cpm FLOAT64, cpcv FLOAT64,
      products ARRAY<STRING>, o2o_impressoes INT64, o2o_views INT64,
      has_bonus BOOL, bonus_o2o_impressoes INT64, bonus_o2o_views INT64,
      ooh_link STRING, audiences STRING, pracas_type STRING, pracas_detail STRING,
      had_cs_meeting BOOL, marketplaces ARRAY<STRING>, features ARRAY<STRING>,
      feature_volumes JSON, pecas_link STRING, redirect_urls ARRAY<STRING>,
      pi_link STRING, proposta_link STRING,
      cs_name STRING, cs_email STRING, submitted_by STRING, submitted_by_email STRING,
      short_token STRING,
      extras JSON,
      created_at TIMESTAMP
    )`,
  team_members: `
    CREATE TABLE IF NOT EXISTS \`${PROJECT}.${DATASET}.team_members\` (
      email STRING, name STRING, role STRING,
      added_by STRING, added_at TIMESTAMP,
      active BOOL
    )`
}

// ══════════════════════════════════════════════════════════════════════════════
// ROUTES
// ══════════════════════════════════════════════════════════════════════════════

app.get('/health', (_, res) => res.json({ status: 'ok', service: 'hypr-command', ts: new Date() }))

// ── Setup BQ tables ─────────────────────────────────────────────────────────
app.post('/setup', async (req, res) => {
  try {
    for (const [name, sql] of Object.entries(SETUP_SQL)) {
      await bq.query({ query: sql, useLegacySql: false })
      console.log(`✅ Table ${name} ready`)
    }
    res.json({ ok: true, message: 'All tables created' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── Clients from Google Sheet ───────────────────────────────────────────────
app.get('/clients', async (req, res) => {
  try {
    const data = await getClientsFromSheet()
    res.json({ ok: true, clients: data, count: data.length })
  } catch (err) {
    console.error(err)
    res.status(500).json({ ok: false, error: err.message })
  }
})

// ── CAMPAIGNS ───────────────────────────────────────────────────────────────
app.get('/campaigns', async (req, res) => {
  try {
    const { month, year } = req.query
    let sql = `SELECT * FROM \`${PROJECT}.${DATASET}.campaigns\``
    const where = []
    if (month) where.push(`EXTRACT(MONTH FROM start_date) = ${parseInt(month)}`)
    if (year) where.push(`EXTRACT(YEAR FROM start_date) = ${parseInt(year)}`)
    if (where.length) sql += ` WHERE ${where.join(' AND ')}`
    sql += ` ORDER BY start_date DESC`
    res.json(await query(sql))
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.post('/campaigns', async (req, res) => {
  try {
    const c = req.body
    await bq.dataset(DATASET).table('campaigns').insert([{
      id: crypto.randomUUID(),
      client: c.client, campaign: c.campaign,
      start_date: c.start, end_date: c.end,
      pacing_display: c.pacing_display ?? null,
      pacing_video: c.pacing_video ?? null,
      ctr: c.ctr ?? null, vtr: c.vtr ?? null,
      features: c.features || [],
      investment: c.investment ? parseFloat(c.investment) : null,
      created_at: new Date().toISOString(),
    }])
    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── TASKS ────────────────────────────────────────────────────────────────────
app.get('/tasks', async (req, res) => {
  try {
    const { cs, status } = req.query
    let sql = `SELECT * FROM \`${PROJECT}.${DATASET}.tasks\``
    const where = []
    if (cs) where.push(`cs = '${cs}'`)
    if (status) where.push(`status = '${status}'`)
    if (where.length) sql += ` WHERE ${where.join(' AND ')}`
    sql += ` ORDER BY created_at DESC`
    const rows = await query(sql)
    // Normalize legacy status values to the new vocabulary (aberta/iniciada/entregue).
    // Old values: 'open', 'pending' → 'aberta'; 'completed' → 'entregue'.
    const normalized = rows.map(r => {
      const s = (r.status || '').toLowerCase()
      let next = r.status
      if (s === 'open' || s === 'pending' || s === '') next = 'aberta'
      else if (s === 'completed') next = 'entregue'
      return { ...r, status: next }
    })
    res.json(normalized)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.post('/tasks', async (req, res) => {
  try {
    const t = req.body
    const id = crypto.randomUUID()
    const now = new Date().toISOString()
    const slaLabel = t.sla || '—'

    // Save to BigQuery via SQL INSERT (NOT streaming insert) — keeps the row
    // immediately available for UPDATE/DELETE in the PUT endpoint without going
    // through the streaming buffer (which blocks DML for ~90 min).
    const escStr = v => {
      if (v === null || v === undefined || v === '') return 'NULL'
      const s = String(v).replace(/"""/g, '""\\"')
      return `r"""${s}"""`
    }
    const escNum = v => {
      if (v === null || v === undefined || v === '') return 'NULL'
      const n = Number(v)
      return isNaN(n) ? 'NULL' : String(n)
    }
    const escDate = v => v ? `DATE '${String(v).split('T')[0].replace(/'/g, "''")}'` : 'NULL'
    const escTs   = v => v ? `TIMESTAMP '${String(v).replace(/'/g, "''")}'` : 'NULL'
    const escArr  = arr => {
      if (!Array.isArray(arr) || arr.length === 0) return '[]'
      return '[' + arr.map(x => escStr(x)).join(', ') + ']'
    }

    const insertCols = [
      'id','type','client','agency','products','features','budget',
      'briefing','cs','cs_email','status','deadline','doc_link',
      'requested_by','requester_email','sla','is_sa','created_at','updated_at',
    ]
    const insertVals = [
      escStr(id),
      escStr(t.type),
      escStr(t.client),
      escStr(t.agency || null),
      escArr(t.products || []),
      escArr(t.features || []),
      escNum(t.budget),
      escStr(t.briefing),
      escStr(t.cs),
      escStr(t.csEmail || null),
      escStr('aberta'),
      escDate(t.deadline),
      'NULL', // doc_link
      escStr(t.requestedBy || null),
      escStr(t.requesterEmail || null),
      escStr(slaLabel),
      t.isSA === true ? 'TRUE' : (t.isSA === false ? 'FALSE' : 'NULL'),
      escTs(now),
      escTs(now),
    ]
    const insertSQL = `INSERT INTO \`${PROJECT}.${DATASET}.tasks\` (${insertCols.join(', ')}) VALUES (${insertVals.join(', ')})`
    await bq.query({ query: insertSQL, useLegacySql: false })

    const taskData = { ...t, id, sla: slaLabel }

    // Email → CS (responsável) — com Gian em CC se for task com SA
    if (t.csEmail) {
      await sendEmail(
        t.csEmail,
        `[HYPR Command] 📋 Nova Task — ${t.type} | ${t.client}`,
        emailTaskCreatedCS(taskData),
        t.isSA === true ? 'gian.nardo@hypr.mobi' : null
      )
    }

    // Email → CP (solicitante)
    if (t.requesterEmail) {
      await sendEmail(
        t.requesterEmail,
        `[HYPR Command] ✅ Task Criada — ${t.type} | ${t.client}`,
        emailTaskCreatedCP(taskData)
      )
    }

    res.json({ ok: true, id })
  } catch (err) {
    console.error('[POST /tasks] error:', err.message, err.stack)
    res.status(500).json({ error: err.message })
  }
})

app.put('/tasks/:id', async (req, res) => {
  try {
    const { id } = req.params
    const updates = req.body
    const now = new Date().toISOString()

    // Permission check: only the CS owner can change status (frontend sends `changedByEmail`).
    // Skipped when only updating doc_link (those edits stay open).
    if (updates.status !== undefined && updates.task && updates.changedByEmail) {
      const ownerEmail = (updates.task.csEmail || updates.task.cs_email || '').toLowerCase()
      if (ownerEmail && ownerEmail !== updates.changedByEmail.toLowerCase()) {
        return res.status(403).json({ error: 'Apenas o CS responsável pode alterar o status desta task.' })
      }
    }

    // FULL EDIT mode: when frontend sends `edit: true`, allow editing all fields.
    // Permission: superuser (matheus.machado) OR requester (CP) OR CS responsible.
    if (updates.edit === true) {
      const SUPERUSER = 'matheus.machado@hypr.mobi'
      const editorEmail = (updates.editedByEmail || '').toLowerCase()

      // Look up current task to verify permissions
      const idEsc = id.replace(/'/g, "''")
      const rows = await query(
        `SELECT id, requester_email, cs_email FROM \`${PROJECT}.${DATASET}.tasks\` WHERE id = '${idEsc}' LIMIT 1`
      )
      if (!rows || rows.length === 0) {
        return res.status(404).json({ error: 'Task não encontrada' })
      }
      const original = rows[0]
      const allowed = new Set([
        SUPERUSER,
        (original.requester_email || '').toLowerCase(),
        (original.cs_email || '').toLowerCase(),
      ].filter(Boolean))
      if (!allowed.has(editorEmail)) {
        return res.status(403).json({ error: 'Apenas o solicitante, o CS responsável ou o admin podem editar esta task.' })
      }

      const t = updates.task || {}
      
      // Use parameterized queries to safely handle special chars (quotes, newlines, etc)
      // Build SET clauses with @paramName and pass values via params object
      const params = {
        type: t.type || null,
        client: t.client || null,
        agency: t.agency || null,
        products: Array.isArray(t.products) ? t.products : [],
        features: Array.isArray(t.features) ? t.features : [],
        budget: (t.budget === null || t.budget === undefined || t.budget === '') ? null : Number(t.budget),
        briefing: t.briefing || null,
        cs: t.cs || null,
        cs_email: t.csEmail || t.cs_email || null,
        deadline: null, // set below after parsing
        sla: t.sla || '—',
        updated_at: now,
        task_id: id,
      }
      // deadline as DATE: extract YYYY-MM-DD
      if (t.deadline) {
        const datePart = String(t.deadline).split('T')[0].split(' ')[0]
        if (/^\d{4}-\d{2}-\d{2}$/.test(datePart)) params.deadline = datePart
      }

      // BigQuery types so empty arrays work
      const types = {
        type: 'STRING',
        client: 'STRING',
        agency: 'STRING',
        products: ['STRING'],
        features: ['STRING'],
        budget: 'FLOAT64',
        briefing: 'STRING',
        cs: 'STRING',
        cs_email: 'STRING',
        deadline: 'DATE',
        sla: 'STRING',
        updated_at: 'TIMESTAMP',
        task_id: 'STRING',
      }

      const updateSql = `UPDATE \`${PROJECT}.${DATASET}.tasks\` SET
        type = @type,
        client = @client,
        agency = @agency,
        products = @products,
        features = @features,
        budget = @budget,
        briefing = @briefing,
        cs = @cs,
        cs_email = @cs_email,
        deadline = @deadline,
        sla = @sla,
        updated_at = @updated_at
        WHERE id = @task_id`

      try {
        await bq.query({
          query: updateSql,
          params,
          types,
          useLegacySql: false,
        })
      } catch (sqlErr) {
        console.error('[edit task] BigQuery UPDATE failed:', sqlErr.message)
        console.error('Params:', JSON.stringify(params))
        return res.status(500).json({ error: 'Falha no BigQuery: ' + sqlErr.message })
      }

      // Notify CS responsible AND CP (requester)
      const editedTask = { ...t, id, editedBy: updates.editedBy, editedByEmail: updates.editedByEmail }
      const notifiedEmails = new Set()
      const csTo = t.csEmail || t.cs_email
      if (csTo) {
        notifiedEmails.add(csTo.toLowerCase())
        await sendEmail(
          csTo,
          `[HYPR Command] ✏️ Task Editada — ${t.type} | ${t.client}`,
          emailTaskEdited(editedTask)
        )
      }
      if (t.requesterEmail && !notifiedEmails.has(t.requesterEmail.toLowerCase())) {
        await sendEmail(
          t.requesterEmail,
          `[HYPR Command] ✏️ Task Editada — ${t.type} | ${t.client}`,
          emailTaskEdited(editedTask)
        )
      }

      return res.json({ ok: true, edited: true })
    }

    // Legacy: status / doc_link partial updates
    const setClauses = []
    if (updates.status !== undefined) setClauses.push(`status = '${updates.status}'`)
    if (updates.doc_link !== undefined) setClauses.push(`doc_link = '${(updates.doc_link || '').replace(/'/g, "''")}'`)
    setClauses.push(`updated_at = '${now}'`)

    await bq.query({
      query: `UPDATE \`${PROJECT}.${DATASET}.tasks\` SET ${setClauses.join(', ')} WHERE id = '${id}'`,
      useLegacySql: false
    })

    // Email notifications based on status change
    if (updates.task) {
      const t = updates.task
      // Iniciada → notify CP (requester)
      if ((updates.status === 'iniciada') && t.requesterEmail) {
        await sendEmail(
          t.requesterEmail,
          `[HYPR Command] ▶ Task Iniciada — ${t.type} | ${t.client}`,
          emailTaskStarted({ ...t, id, message: updates.message || '' })
        )
      }
      // Entregue (or legacy completed) → notify CP
      if ((updates.status === 'entregue' || updates.status === 'completed') && t.requesterEmail) {
        await sendEmail(
          t.requesterEmail,
          `[HYPR Command] ✅ Task Concluída — ${t.type} | ${t.client}`,
          emailTaskCompleted({ ...t, id })
        )
      }
    }

    res.json({ ok: true })
  } catch (err) {
    console.error('[PUT /tasks/:id] error:', err.message, err.stack)
    res.status(500).json({ error: err.message })
  }
})

// ── CHECKLISTS ──────────────────────────────────────────────────────────────
app.post('/checklists', async (req, res) => {
  try {
    const f = req.body
    const now = new Date().toISOString()

    // Capture all dynamic fields (per-product volumes, feature volumes, surveys, etc.)
    // These come from the frontend with prefixes that don't map to fixed BQ columns.
    const KNOWN_KEYS = new Set([
      'cp_name','cp_email','agency','industry','campaign_type','client','campaign_name',
      'start_date','end_date','investment','deal_dv360','formats','cpm','cpcv','products',
      'o2o_impressoes','o2o_views','has_bonus','bonus_o2o_impressoes','bonus_o2o_views',
      'ooh_link','audiences','pracas_type','pracas_detail','had_cs_meeting','marketplaces',
      'features','feature_volumes','pecas_link','redirect_urls','extra_urls','pi_link',
      'proposta_link','cs_name','cs_email','submitted_by','submitted_by_email','submittedBy',
      'submittedByEmail','short_token',
      // Note: praças_* dynamic fields (states, cities, other) are intentionally
      // NOT in this list — they are captured into `extras` so the detail view
      // can render them back. Only `pracas_type` and `pracas_detail` are mapped
      // to fixed columns above.
    ])
    const extras = {}
    for (const [key, value] of Object.entries(f)) {
      if (KNOWN_KEYS.has(key)) continue
      if (value === undefined || value === null || value === '') continue
      extras[key] = value
    }

    // Save to BigQuery via SQL INSERT (NOT streaming insert) — keeps the row
    // immediately available for UPDATE/DELETE in the PUT endpoint without going
    // through the streaming buffer (which blocks DML for ~90 min).
    const newId = crypto.randomUUID()
    const escStr = v => {
      if (v === null || v === undefined || v === '') return 'NULL'
      const s = String(v).replace(/"""/g, '""\\"')
      return `r"""${s}"""`
    }
    const escNum = v => {
      if (v === null || v === undefined || v === '') return 'NULL'
      const n = Number(v)
      return isNaN(n) ? 'NULL' : String(n)
    }
    const escBool = v => (v === 'Sim' || v === true || v === 'true') ? 'TRUE' : 'FALSE'
    const escDate = v => v ? `DATE '${String(v).replace(/'/g, "''")}'` : 'NULL'
    const escTs   = v => v ? `TIMESTAMP '${String(v).replace(/'/g, "''")}'` : 'NULL'
    const escArr  = arr => {
      if (!Array.isArray(arr) || arr.length === 0) return '[]'
      return '[' + arr.map(x => escStr(x)).join(', ') + ']'
    }
    const escJson = obj => {
      const s = JSON.stringify(obj || {}).replace(/"""/g, '""\\"')
      return `JSON r"""${s}"""`
    }
    const insertCols = [
      'id','cp_name','cp_email','agency','industry','campaign_type','client','campaign_name',
      'start_date','end_date','investment','deal_dv360','formats','cpm','cpcv','products',
      'o2o_impressoes','o2o_views','has_bonus','bonus_o2o_impressoes','bonus_o2o_views',
      'ooh_link','audiences','pracas_type','pracas_detail','had_cs_meeting','marketplaces',
      'features','feature_volumes','pecas_link','redirect_urls','pi_link','proposta_link',
      'cs_name','cs_email','submitted_by','submitted_by_email','short_token','extras','created_at',
    ]
    const insertVals = [
      escStr(newId),
      escStr(f.cp_name), escStr(f.cp_email),
      escStr(f.agency), escStr(f.industry), escStr(f.campaign_type),
      escStr(f.client), escStr(f.campaign_name),
      escDate(f.start_date), escDate(f.end_date),
      escNum(f.investment),
      escBool(f.deal_dv360),
      escArr(f.formats || []),
      escNum(f.cpm), escNum(f.cpcv),
      escArr(f.products || []),
      escNum(f.o2o_impressoes), escNum(f.o2o_views),
      escBool(f.has_bonus),
      escNum(f.bonus_o2o_impressoes), escNum(f.bonus_o2o_views),
      escStr(f.ooh_link), escStr(f.audiences),
      escStr(f.pracas_type || f.praças_type),
      escStr(f.pracas_detail || f.praças_state || f.praças_city || f.praças_other),
      escBool(f.had_cs_meeting),
      escArr(f.marketplaces || []),
      escArr(f.features || []),
      escJson(f.feature_volumes || {}),
      escStr(f.pecas_link),
      escArr((f.extra_urls || []).filter(Boolean)),
      escStr(f.pi_link), escStr(f.proposta_link),
      escStr(f.cs_name), escStr(f.cs_email),
      escStr(f.submittedBy), escStr(f.submittedByEmail),
      escStr(f.short_token),
      escJson(extras),
      escTs(now),
    ]
    const insertSQL = `INSERT INTO \`${PROJECT}.${DATASET}.checklists\` (${insertCols.join(', ')}) VALUES (${insertVals.join(', ')})`
    await bq.query({ query: insertSQL, useLegacySql: false })

    const emailData = {
      client: f.client, agency: f.agency,
      campaignName: f.campaign_name, campaignType: f.campaign_type,
      industry: f.industry,
      startDate: f.start_date, endDate: f.end_date,
      investment: f.investment ? parseFloat(f.investment) : null,
      dealDv360: f.deal_dv360 === 'Sim' || f.deal_dv360 === true,
      formats: f.formats, cpm: f.cpm ? parseFloat(f.cpm) : null,
      cpcv: f.cpcv ? parseFloat(f.cpcv) : null,
      products: f.products, features: f.features,
      audiences: f.audiences,
      pracasDetail: f.pracas_detail || f.praças_state || f.praças_city || f.praças_other || null,
      csName: f.cs_name, csEmail: f.cs_email,
      submittedBy: f.submittedBy || f.cp_name,
      submittedByEmail: f.submittedByEmail || f.cp_email,
    }

    // Email → CP (solicitante)
    const cpEmail = f.submittedByEmail || f.cp_email
    if (cpEmail) {
      await sendEmail(
        cpEmail,
        `[HYPR Command] ✅ Checklist Enviado — ${f.campaign_name} | ${f.client}`,
        emailChecklistCP(emailData)
      )
    }

    // Email → CS (responsável)
    if (f.cs_email) {
      await sendEmail(
        f.cs_email,
        `[HYPR Command] 📋 Novo Checklist — ${f.campaign_name} | ${f.client}`,
        emailChecklistCS(emailData)
      )
    }

    // Mirror to Report Hub (prod_assets.checklist_info) so the Report Hub sees this campaign
    await syncToReportHub(f, false)

    res.json({ ok: true, id: newId })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
})

app.get('/checklists', async (req, res) => {
  try {
    const rows = await query(
      `SELECT * FROM \`${PROJECT}.${DATASET}.checklists\` ORDER BY created_at DESC LIMIT 100`
    )
    // Hydrate `extras` JSON back into the row, so dynamic fields like O2O_imp,
    // OOH_imp, fv_Topics_*, ftext_Survey, cl_features, etc. are visible to the frontend.
    const hydrated = rows.map(row => {
      const out = { ...row }
      if (row.extras) {
        let parsed = row.extras
        if (typeof parsed === 'string') {
          try { parsed = JSON.parse(parsed) } catch { parsed = {} }
        }
        if (parsed && typeof parsed === 'object') {
          for (const [k, v] of Object.entries(parsed)) {
            // Don't overwrite existing fixed columns
            if (out[k] === undefined || out[k] === null) out[k] = v
          }
        }
      }
      // Also parse feature_volumes JSON if it came as a string
      if (typeof out.feature_volumes === 'string') {
        try { out.feature_volumes = JSON.parse(out.feature_volumes) } catch {}
      }
      return out
    })
    res.json(hydrated)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── PUT /checklists/:id — update existing checklist (used by Edit modal) ────
app.put('/checklists/:id', async (req, res) => {
  try {
    const { id } = req.params
    const f = req.body

    // BigQuery returns DATE/TIMESTAMP fields as { value: '...' } objects.
    // When the frontend sends the row back unchanged, those wrappers come along.
    // Unwrap any { value: ... } objects to their primitive value.
    const unwrap = v => {
      if (v && typeof v === 'object' && !Array.isArray(v) && 'value' in v && Object.keys(v).length === 1) return v.value
      return v
    }
    for (const k of Object.keys(f)) f[k] = unwrap(f[k])

    // Same separation as POST: known fixed columns vs. dynamic extras
    const KNOWN_KEYS = new Set([
      'cp_name','cp_email','agency','industry','campaign_type','client','campaign_name',
      'start_date','end_date','investment','deal_dv360','formats','cpm','cpcv','products',
      'o2o_impressoes','o2o_views','has_bonus','bonus_o2o_impressoes','bonus_o2o_views',
      'ooh_link','audiences','pracas_type','pracas_detail','had_cs_meeting','marketplaces',
      'features','feature_volumes','pecas_link','redirect_urls','extra_urls','pi_link',
      'proposta_link','cs_name','cs_email','submitted_by','submitted_by_email','submittedBy',
      'submittedByEmail','short_token','id','created_at','updated_at','extras',
      // praças_* dynamic fields fall through to `extras` (same reason as POST)
    ])
    const extras = {}
    for (const [key, value] of Object.entries(f)) {
      if (KNOWN_KEYS.has(key)) continue
      if (value === undefined || value === null || value === '') continue
      extras[key] = value
    }

    // Build UPDATE statement
    const esc = v => {
      if (v === null || v === undefined) return 'NULL'
      if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE'
      if (typeof v === 'number') return String(v)
      const escapeStr = s => String(s).replace(/"""/g, '""\\"')
      if (Array.isArray(v)) return `[${v.map(x=>`r"""${escapeStr(x)}"""`).join(',')}]`
      return `r"""${escapeStr(v)}"""`
    }
    const sets = []
    const fld = (col, val) => { if (val !== undefined) sets.push(`${col} = ${esc(val)}`) }

    fld('cp_name', f.cp_name ?? null)
    fld('cp_email', f.cp_email ?? null)
    fld('agency', f.agency ?? null)
    fld('industry', f.industry ?? null)
    fld('campaign_type', f.campaign_type ?? null)
    if (f.client !== undefined) fld('client', f.client)
    if (f.campaign_name !== undefined) fld('campaign_name', f.campaign_name)
    if (f.start_date !== undefined) sets.push(`start_date = ${f.start_date ? `DATE '${f.start_date}'` : 'NULL'}`)
    if (f.end_date !== undefined) sets.push(`end_date = ${f.end_date ? `DATE '${f.end_date}'` : 'NULL'}`)
    if (f.investment !== undefined) sets.push(`investment = ${f.investment ? parseFloat(f.investment) : 'NULL'}`)
    if (f.deal_dv360 !== undefined) sets.push(`deal_dv360 = ${f.deal_dv360 === 'Sim' || f.deal_dv360 === true ? 'TRUE' : 'FALSE'}`)
    if (f.formats !== undefined) sets.push(`formats = ${esc(f.formats || [])}`)
    if (f.cpm !== undefined) sets.push(`cpm = ${f.cpm ? parseFloat(f.cpm) : 'NULL'}`)
    if (f.cpcv !== undefined) sets.push(`cpcv = ${f.cpcv ? parseFloat(f.cpcv) : 'NULL'}`)
    if (f.products !== undefined) sets.push(`products = ${esc(f.products || [])}`)
    if (f.o2o_impressoes !== undefined) sets.push(`o2o_impressoes = ${f.o2o_impressoes ? parseInt(f.o2o_impressoes) : 'NULL'}`)
    if (f.o2o_views !== undefined) sets.push(`o2o_views = ${f.o2o_views ? parseInt(f.o2o_views) : 'NULL'}`)
    if (f.has_bonus !== undefined) sets.push(`has_bonus = ${f.has_bonus === 'Sim' || f.has_bonus === true ? 'TRUE' : 'FALSE'}`)
    if (f.bonus_o2o_impressoes !== undefined) sets.push(`bonus_o2o_impressoes = ${f.bonus_o2o_impressoes ? parseInt(f.bonus_o2o_impressoes) : 'NULL'}`)
    if (f.bonus_o2o_views !== undefined) sets.push(`bonus_o2o_views = ${f.bonus_o2o_views ? parseInt(f.bonus_o2o_views) : 'NULL'}`)
    fld('ooh_link', f.ooh_link ?? null)
    fld('audiences', f.audiences ?? null)
    if (f.pracas_type !== undefined || f.praças_type !== undefined) fld('pracas_type', f.pracas_type || f.praças_type || null)
    if (f.pracas_detail !== undefined) fld('pracas_detail', f.pracas_detail ?? null)
    if (f.had_cs_meeting !== undefined) sets.push(`had_cs_meeting = ${f.had_cs_meeting === 'Sim' || f.had_cs_meeting === true ? 'TRUE' : 'FALSE'}`)
    if (f.marketplaces !== undefined) sets.push(`marketplaces = ${esc(f.marketplaces || [])}`)
    if (f.features !== undefined) sets.push(`features = ${esc(f.features || [])}`)
    const escJsonStr = obj => {
      const s = JSON.stringify(obj || {}).replace(/"""/g, '""\\"')
      return s
    }

    if (f.feature_volumes !== undefined) sets.push(`feature_volumes = JSON r"""${escJsonStr(f.feature_volumes)}"""`)
    fld('pecas_link', f.pecas_link ?? null)
    if (f.extra_urls !== undefined) sets.push(`redirect_urls = ${esc((f.extra_urls || []).filter(Boolean))}`)
    fld('pi_link', f.pi_link ?? null)
    fld('proposta_link', f.proposta_link ?? null)
    fld('cs_name', f.cs_name ?? null)
    fld('cs_email', f.cs_email ?? null)
    sets.push(`extras = JSON r"""${escJsonStr(extras)}"""`)

    const sql = `UPDATE \`${PROJECT}.${DATASET}.checklists\` SET ${sets.join(', ')} WHERE id = '${id}'`
    await bq.query({ query: sql, useLegacySql: false })

    // Mirror the edit to Report Hub: delete-then-insert by short_token so we
    // never accumulate duplicate Command-originated rows.
    await syncToReportHub(f, true)

    res.json({ ok: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
})

// ── DELETE /checklists/:id ──────────────────────────────────────────────────
// Permissions: superuser (matheus.machado@hypr.mobi) OR the CP who submitted
// OR the CS responsible. Removes from both checklists and prod_assets.checklist_info.
app.delete('/checklists/:id', async (req, res) => {
  try {
    const { id } = req.params
    const requesterEmail = (req.body?.requesterEmail || '').toLowerCase()
    const SUPERUSER = 'matheus.machado@hypr.mobi'

    // Look up the row to check permissions and grab short_token for Report Hub cleanup
    const idEsc = id.replace(/'/g, "''")
    const rows = await query(
      `SELECT id, short_token, cp_email, submitted_by_email, cs_email FROM \`${PROJECT}.${DATASET}.checklists\` WHERE id = '${idEsc}' LIMIT 1`
    )
    if (!rows || rows.length === 0) {
      return res.status(404).json({ error: 'Checklist não encontrado' })
    }
    const row = rows[0]
    const allowed = new Set([
      SUPERUSER,
      (row.cp_email || '').toLowerCase(),
      (row.submitted_by_email || '').toLowerCase(),
      (row.cs_email || '').toLowerCase(),
    ].filter(Boolean))
    if (!allowed.has(requesterEmail)) {
      return res.status(403).json({ error: 'Apenas o CP, o CS responsável ou o admin podem excluir este checklist.' })
    }

    // Delete from main table
    await bq.query({
      query: `DELETE FROM \`${PROJECT}.${DATASET}.checklists\` WHERE id = '${idEsc}'`,
      useLegacySql: false,
    })

    // Delete from Report Hub mirror (if short_token exists)
    if (row.short_token) {
      try {
        const tokenEsc = String(row.short_token).replace(/'/g, "''")
        await bq.query({
          query: `DELETE FROM \`${REPORT_HUB_TABLE}\` WHERE short_token = '${tokenEsc}'`,
          useLegacySql: false,
        })
        console.log(`🗑 Report Hub row removed: ${row.short_token}`)
      } catch (err) {
        // Don't fail the deletion if Report Hub cleanup fails — just log it.
        console.error(`⚠ Failed to remove Report Hub row for ${row.short_token}:`, err.message)
      }
    }

    res.json({ ok: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
})

// ── TEAM MEMBERS ───────────────────────────────────────────────────────────
// Roles: 'admin' (cumulative — has admin + sales + cs access), 'sales', 'cs', 'none'
// Permissions: anyone @hypr.mobi can read (filtered to active=true). Only admins can write.

// Seed initial members (run once, no-op if rows already exist for those emails)
const SEED_TEAM = [
  // Admins
  { email: 'matheus.machado@hypr.mobi', name: 'Matheus Machado',  role: 'admin' },
  { email: 'gian.nardo@hypr.mobi',      name: 'Gian Nardo',       role: 'admin' },
  { email: 'mateus.lambranho@hypr.mobi',name: 'Mateus Lambranho', role: 'admin' },
  { email: 'cesar.moura@hypr.mobi',     name: 'Cesar Moura',      role: 'admin' },
  { email: 'adrian.ferguson@hypr.mobi', name: 'Adrian Ferguson',  role: 'admin' },
  // Sales
  { email: 'danilo.pereira@hypr.mobi',   name: 'Danilo Pereira',   role: 'sales' },
  { email: 'eduarda.bolzan@hypr.mobi',   name: 'Eduarda Bolzan',   role: 'sales' },
  { email: 'camila.tenorio@hypr.mobi',   name: 'Camila Tenorio',   role: 'sales' },
  { email: 'egle.stein@hypr.mobi',       name: 'Egle Stein',       role: 'sales' },
  { email: 'alexandra.perez@hypr.mobi',  name: 'Alexandra Perez',  role: 'sales' },
  { email: 'karol.siqueira@hypr.mobi',   name: 'Karol Siqueira',   role: 'sales' },
  { email: 'pablo.souza@hypr.mobi',      name: 'Pablo Souza',      role: 'sales' },
  { email: 'larissa.reis@hypr.mobi',     name: 'Larissa Reis',     role: 'sales' },
  { email: 'marcelo.nogueira@hypr.mobi', name: 'Marcelo Nogueira', role: 'sales' },
  // CS
  { email: 'beatriz.severine@hypr.mobi', name: 'Beatriz Severine',  role: 'cs' },
  { email: 'isaac.lobo@hypr.mobi',       name: 'Isaac Agiman',      role: 'cs' },
  { email: 'joao.armelin@hypr.mobi',     name: 'João Armelin',      role: 'cs' },
  { email: 'joao.buzolin@hypr.mobi',     name: 'João Buzolin',      role: 'cs' },
  { email: 'mariana.lewinski@hypr.mobi', name: 'Mariana Lewinski',  role: 'cs' },
  { email: 'thiago.nascimento@hypr.mobi',name: 'Thiago Nascimento', role: 'cs' },
]

async function seedTeamIfEmpty() {
  try {
    const rows = await query(`SELECT COUNT(*) as c FROM \`${PROJECT}.${DATASET}.team_members\``)
    if (rows && rows[0] && Number(rows[0].c) > 0) return
    const now = new Date().toISOString()
    const valuesSql = SEED_TEAM.map(m =>
      `('${m.email}', '${m.name.replace(/'/g, "''")}', '${m.role}', 'system-seed', TIMESTAMP '${now}', TRUE)`
    ).join(', ')
    await bq.query({
      query: `INSERT INTO \`${PROJECT}.${DATASET}.team_members\` (email, name, role, added_by, added_at, active) VALUES ${valuesSql}`,
      useLegacySql: false,
    })
    console.log(`✅ Seeded ${SEED_TEAM.length} team members`)
  } catch (err) {
    console.error('Team seed failed:', err.message)
  }
}

async function isAdminEmail(email) {
  if (!email) return false
  const e = String(email).toLowerCase().replace(/'/g, "''")
  const rows = await query(
    `SELECT role FROM \`${PROJECT}.${DATASET}.team_members\` WHERE LOWER(email)='${e}' AND active=TRUE LIMIT 1`
  )
  return rows && rows[0] && rows[0].role === 'admin'
}

// GET /team — list all active members (anyone @hypr.mobi can read)
app.get('/team', async (req, res) => {
  try {
    await seedTeamIfEmpty()
    const rows = await query(
      `SELECT email, name, role, added_by, added_at, active FROM \`${PROJECT}.${DATASET}.team_members\` WHERE active=TRUE ORDER BY role, name`
    )
    res.json(rows)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /team — add or update a member (admin only)
app.post('/team', async (req, res) => {
  try {
    const { email, name, role, requesterEmail } = req.body
    if (!email || !name || !role) return res.status(400).json({ error: 'email, name e role são obrigatórios' })
    if (!['admin','sales','cs','none'].includes(role)) return res.status(400).json({ error: 'role inválido' })
    if (!String(email).toLowerCase().endsWith('@hypr.mobi')) return res.status(400).json({ error: 'apenas emails @hypr.mobi' })

    if (!(await isAdminEmail(requesterEmail))) {
      return res.status(403).json({ error: 'Apenas admins podem adicionar/alterar membros' })
    }

    const e = String(email).toLowerCase().replace(/'/g, "''")
    const n = String(name).replace(/'/g, "''")
    const r = role
    const by = String(requesterEmail).toLowerCase().replace(/'/g, "''")
    const now = new Date().toISOString()

    // Upsert: delete existing then insert (prevents streaming-buffer DML issues)
    await bq.query({
      query: `DELETE FROM \`${PROJECT}.${DATASET}.team_members\` WHERE LOWER(email)='${e}'`,
      useLegacySql: false,
    })
    await bq.query({
      query: `INSERT INTO \`${PROJECT}.${DATASET}.team_members\`
              (email, name, role, added_by, added_at, active)
              VALUES ('${e}', '${n}', '${r}', '${by}', TIMESTAMP '${now}', TRUE)`,
      useLegacySql: false,
    })
    console.log(`👥 Team member upserted: ${email} as ${role} by ${requesterEmail}`)
    res.json({ ok: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
})

// DELETE /team/:email — remove a member (admin only). Soft-delete via active=false.
app.delete('/team/:email', async (req, res) => {
  try {
    const targetEmail = decodeURIComponent(req.params.email).toLowerCase()
    const requesterEmail = (req.body?.requesterEmail || '').toLowerCase()

    if (!(await isAdminEmail(requesterEmail))) {
      return res.status(403).json({ error: 'Apenas admins podem remover membros' })
    }
    if (targetEmail === requesterEmail) {
      return res.status(400).json({ error: 'Você não pode se remover. Peça para outro admin.' })
    }
    // Hard delete (DELETE works for non-streaming-buffered rows)
    const e = targetEmail.replace(/'/g, "''")
    await bq.query({
      query: `DELETE FROM \`${PROJECT}.${DATASET}.team_members\` WHERE LOWER(email)='${e}'`,
      useLegacySql: false,
    })
    console.log(`🗑 Team member removed: ${targetEmail} by ${requesterEmail}`)
    res.json({ ok: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
})

// ── PROPOSALS ───────────────────────────────────────────────────────────────
app.get('/proposals', async (req, res) => {
  try {
    const { status, created_by_email } = req.query
    let sql = `SELECT * FROM \`${PROJECT}.${DATASET}.proposals\``
    const where = []
    if (status) where.push(`status = '${status}'`)
    if (created_by_email) where.push(`created_by_email = '${created_by_email}'`)
    if (where.length) sql += ` WHERE ${where.join(' AND ')}`
    sql += ` ORDER BY created_at DESC LIMIT 100`
    res.json(await query(sql))
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.post('/proposals', async (req, res) => {
  try {
    const p = req.body
    const id = crypto.randomUUID()
    const now = new Date().toISOString()

    // Save to BigQuery
    await bq.dataset(DATASET).table('proposals').insert([{
      id,
      created_at: now,
      created_by: p.createdBy || null,
      created_by_email: p.createdByEmail || null,
      client: p.client,
      agency: p.agency || null,
      period_start: p.periodStart || null,
      period_end: p.periodEnd || null,
      praca: p.praca || 'Nacional',
      project_description: p.projectDescription || null,
      proposal_title: p.proposalTitle || 'Pacote HYPR',
      scope_products: JSON.stringify(p.scopeProducts || []),
      contracted_products: JSON.stringify(p.contractedProducts || []),
      bonifications: JSON.stringify(p.bonifications || []),
      features: p.features || [],
      total_display_volume: p.totalVolumetriaDisplay ? parseInt(p.totalVolumetriaDisplay) : null,
      total_video_volume: p.totalVolumetriaVideo ? parseInt(p.totalVolumetriaVideo) : null,
      total_gross_value: p.totalValorBruto ? parseFloat(p.totalValorBruto) : null,
      total_net_value: p.totalValorLiquido ? parseFloat(p.totalValorLiquido) : null,
      total_bonification_value: p.totalBonificacao ? parseFloat(p.totalBonificacao) : null,
      status: p.status || 'draft',
      last_updated: now,
    }])

    res.json({ ok: true, id })
  } catch (err) {
    console.error('Error creating proposal:', err)
    res.status(500).json({ error: err.message })
  }
})

app.put('/proposals/:id', async (req, res) => {
  try {
    const { id } = req.params
    const updates = req.body
    const now = new Date().toISOString()

    const setClauses = []
    if (updates.status !== undefined) setClauses.push(`status = '${updates.status}'`)
    if (updates.client !== undefined) setClauses.push(`client = '${updates.client}'`)
    if (updates.agency !== undefined) setClauses.push(`agency = '${updates.agency}'`)
    // Add more fields as needed
    setClauses.push(`last_updated = '${now}'`)

    await bq.query({
      query: `UPDATE \`${PROJECT}.${DATASET}.proposals\` SET ${setClauses.join(', ')} WHERE id = '${id}'`,
      useLegacySql: false
    })

    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.delete('/proposals/:id', async (req, res) => {
  try {
    const { id } = req.params
    await bq.query({
      query: `DELETE FROM \`${PROJECT}.${DATASET}.proposals\` WHERE id = '${id}'`,
      useLegacySql: false
    })
    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ══════════════════════════════════════════════════════════════════════════════
// START
// ══════════════════════════════════════════════════════════════════════════════
app.listen(PORT, () => {
  console.log(`\n🚀 HYPR Command Backend — http://localhost:${PORT}`)
  console.log(`   BigQuery: ${PROJECT}.${DATASET}`)
  console.log(`   Sheet: ${SHEET_ID}`)
  console.log(`   Frontend: ${FRONTEND_URL}\n`)
})
